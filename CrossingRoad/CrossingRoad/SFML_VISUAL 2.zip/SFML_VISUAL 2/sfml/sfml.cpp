#include "SFML.h"

using namespace std;

int main() {
	sf::RenderWindow window(sf::VideoMode(1024, 512), "Game", sf::Style::Close | sf::Style::Resize);
	Menu menu(window.getSize().x, window.getSize().y);
	sf::Texture background;
	
	background.loadFromFile(path + "background.png");
	sf::RectangleShape bg;
	sf::Vector2f bgs; 
	bgs.x = background.getSize().x;
	bgs.y = background.getSize().y;

	bg.setSize(bgs);
	bg.setOrigin(bgs.x * 0.5f, bgs.y * 0.5f);
	bg.setTextureRect(sf::IntRect(0, 0, bgs.x, bgs.y));
	bg.setTexture(&background);
	bg.setPosition(window.getSize().x * 0.5f, window.getSize().y * 0.5f);
	window.draw(bg);
	window.display();
	
	while (1)
	{
		switch (menu.mainMenu(window,bg))
		{
		case 0://gameplay
			window.clear();
			gamePlay(window);
			break;
		case 1://loadgame
			break;
		case 2: // setting
			break;
		case 3:
			window.close();
			break;
		}
		if (!window.isOpen()) break;
	}
	return 0;
}
