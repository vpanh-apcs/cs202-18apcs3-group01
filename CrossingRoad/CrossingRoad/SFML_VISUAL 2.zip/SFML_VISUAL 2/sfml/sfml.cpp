#include "SFML.h"

using namespace std;

int main() {
	sf::RenderWindow window(sf::VideoMode(1024, 512), "Game", sf::Style::Close | sf::Style::Resize);

	Map gameMap;
	Player user;
	Obstacle o;
	Car car;
	sf::RectangleShape rectUser;

	gameMap.initialSet();
	user.initialSet();
	o.initialSet();
	car.initialSet();

	while (window.isOpen())
	{

		o.obstacleDraw(window);
		window.clear();
		sf::Event event;
		while (window.pollEvent(event))
		{
			rectUser = user.move(window,event);
		}
		gameMap.drawMap(window);
		user.playerDraw(window, rectUser);
		window.display();
		
	}


	return 0;
}
