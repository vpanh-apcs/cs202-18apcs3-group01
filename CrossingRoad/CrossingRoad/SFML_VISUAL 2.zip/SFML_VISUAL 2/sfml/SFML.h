#ifndef _HEADER_H_
#define _HEADER_H_
#include "SFML/Graphics.hpp"
#include <iostream>
#include <vector>
#include <ctime>
using namespace std;
const string path = "image/";

class Map {
private:
	vector <sf::Texture> line;
	sf::Image road, grass;
	sf::Vector2u size;	
	sf::Texture textureEntity, textureLane, texturePlayer;
	sf::RectangleShape rectEntity,rectLane,rectPlayer;
	sf::Vector2f blockSizeFloat;
	sf::Vector2i blockSizeInt;
public:
	void drawMap(sf::RenderWindow& window);
	void landSet();
	void initialSet();
	sf::Vector2u getSize();


};

class Player {
private:
	sf::Image player_front, player_behind, player_left, player_right;
	sf::RectangleShape rectPlayer;
	sf::Texture texturePlayer;
	sf::Vector2f blockSizeFloat/*(16.0f * 2, 16.0f * 2)*/;
	sf::Vector2i blockSizeInt/*(16, 16)*/;
	char currentDirect;
public:
	sf::RectangleShape move(sf::RenderWindow& window, sf::Event& event);
	void initialSet();
	void playerDraw(sf::RenderWindow& window,sf::RectangleShape rectUser);
	
};

class Obstacle {
private:
	sf::Texture textureEntity;
	sf::RectangleShape rectEntity;
	sf::Image tree, rock;
	sf::Vector2f blockSizeFloat;
public:
	void initialSet();
	void obstacleDraw(sf::RenderWindow& window);

};

class Car {
	sf::Image carleft,carright;
	sf::RectangleShape rectCar;
	sf::Vector2f blockSizeFloat;
public:
	void initialSet();
	void carMove();
	void carDraw(sf::RenderWindow& window);
};

#endif