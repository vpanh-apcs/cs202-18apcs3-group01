#include "SFML.h"

//------------M A P------------------------
void Map::initialSet() {
	road.loadFromFile(path + "road.png");
	grass.loadFromFile(path + "grass.png");
	blockSizeInt.x = road.getSize().x;
	blockSizeInt.y = road.getSize().y;
	blockSizeFloat.x = road.getSize().x;
	blockSizeFloat.y = road.getSize().y;
	rectLane.setSize(sf::Vector2f(blockSizeFloat.x * 20, blockSizeFloat.y));
	landSet();
}
void Map::landSet() {
	srand(unsigned(time(0)));
	for (int i = 0; i < 10; ++i) {
		//lane
		int randLane = rand() % 2;
		if (randLane == 1) //Grass
			textureLane.loadFromImage(grass);
		else //Road
			textureLane.loadFromImage(road);
		line.push_back(textureLane);
	}
}
void Map::drawMap(sf::RenderWindow& window) {
	sf::Texture block;
	block.loadFromFile(path + "road.png");
	sf::Vector2u textSize = block.getSize();
		
	for (int i = 0; i < (int)line.size(); ++i) {
		line[i].setRepeated(true);
		rectLane.setTextureRect(sf::IntRect(0, 0, blockSizeFloat.x * 20, blockSizeFloat.y));
		rectLane.setTexture(&line[i]);
		rectLane.setScale(2, 2);
		rectLane.setPosition(50, 50 + i * 16 * 2);
		window.draw(rectLane);
	}
}

//------------P L A Y E R------------------
void Player::initialSet() {
	blockSizeInt.x = 16;
	blockSizeInt.y = 16;
	blockSizeFloat.x = 16.0f * 2;
	blockSizeFloat.y = 16.0f * 2;
	currentDirect = 'S';
	player_front.loadFromFile(path + "player_front.png");
	player_behind.loadFromFile(path + "player_behind.png");
	player_left.loadFromFile(path + "player_left.png");
	player_right.loadFromFile(path + "player_right.png");
	texturePlayer.loadFromImage(player_front);

	rectPlayer.setSize(sf::Vector2f(texturePlayer.getSize().x, texturePlayer.getSize().y));
	rectPlayer.setTextureRect(sf::IntRect(0, 0, texturePlayer.getSize().x, texturePlayer.getSize().y));
	rectPlayer.setTexture(&texturePlayer);
	rectPlayer.setOrigin(texturePlayer.getSize().x, texturePlayer.getSize().y);
	rectPlayer.setPosition(50 + 32, 50 + 32);
	rectPlayer.setScale(2, 2);
}
sf::RectangleShape Player::move(sf::RenderWindow& window, sf::Event& event)
{
	 // default front view

	if (event.type == sf::Event::KeyPressed) {
		switch (event.key.code) {
		case sf::Keyboard::Down:
			if (currentDirect != 'S') {
				texturePlayer.loadFromImage(player_front);
				currentDirect = 'S';
			}
			rectPlayer.move(0, blockSizeFloat.y);
			break;
		case sf::Keyboard::Up:
			if (currentDirect != 'W') {
				texturePlayer.loadFromImage(player_behind);
				currentDirect = 'W';
			}
			rectPlayer.move(0, -blockSizeFloat.y);
			break;
		case sf::Keyboard::Left:
			if (currentDirect != 'A') {
				texturePlayer.loadFromImage(player_left);
				currentDirect = 'A';
			}
			rectPlayer.move(-blockSizeFloat.x, 0);
			break;
		case sf::Keyboard::Right:
			if (currentDirect != 'D') {
				texturePlayer.loadFromImage(player_right);
				currentDirect = 'D';
			}
			rectPlayer.move(+blockSizeFloat.x, 0);
			break;
		}
	}
	return rectPlayer;
}
void Player::playerDraw(sf::RenderWindow& window,sf::RectangleShape rectUser)
{
	window.draw(rectUser);
}

//------------O B S T A C L E--------------
void Obstacle::initialSet() {
	tree.loadFromFile(path + "tree.png");
	rock.loadFromFile(path + "rock.png");
	blockSizeFloat.x = tree.getSize().x;
	blockSizeFloat.y = tree.getSize().y;
}
void Obstacle::obstacleDraw(sf::RenderWindow& window) {
	srand(unsigned(time(0)));
	int randEntity = rand() % 2;
	if (randEntity == 1) //Tree
		textureEntity.loadFromImage(tree);
	else // Rock
		textureEntity.loadFromImage(rock);
	rectEntity.setTextureRect(sf::IntRect(0, 0, blockSizeFloat.x, blockSizeFloat.y));
	rectEntity.setTexture(&textureEntity);
	window.draw(rectEntity);
}

//--------------C A R-------------------
void Car::initialSet() {
	carleft.loadFromFile(path + "carleft.png");
	carright.loadFromFile(path + "carright.png");
	blockSizeFloat.x = carleft.getSize().x;
	blockSizeFloat.y = carleft.getSize().y;
}
void Car::carDraw(sf::RenderWindow& window) {

}
void Car::carMove() {

}